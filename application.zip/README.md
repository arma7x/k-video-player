# KaiKit

## JS framework for KaiOS

## TODO DOCUMENTATION

## Licence

[MIT](https://opensource.org/licenses/MIT)

