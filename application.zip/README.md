# K-Video Player

> K-Video Player is a full-featured video player. Supports VTT/SRT, auto-resume last playback duration, control playback rate, screenshot & more

[MIT](https://opensource.org/licenses/MIT)
